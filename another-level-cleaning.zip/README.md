# Another Level Cleaning Services — Production-Ready Website

Hacker-styled, animated, SEO-friendly Next.js site with a **real AI estimator** that analyzes uploaded photos using **OpenAI Vision** to produce practical pricing.

## Features
- ⚡ Next.js 14 (App Router) + TailwindCSS + Framer Motion
- 💧 Water-like particle hero, smooth scroll animations
- 🔎 SEO meta, OpenGraph
- 🤖 AI Estimator (gpt-4o-mini vision) with real image analysis
- 🧰 Ready for GitHub Codespaces (`.devcontainer`)
- ☁️ One-command deploy to Vercel
- 📞 Business info pre-filled (Jonesboro, AR; NEA coverage)

---

## 1) Quick Start (GitHub Codespaces)

1. Create a new repo, upload/drag this folder or use the zip.
2. Open in **Codespaces** (or clone locally).
3. In terminal:
   ```bash
   npm install
   cp .env.example .env.local
   # Paste your OpenAI API key into .env.local
   npm run dev
   ```
4. Open the forwarded URL → your site is live in dev.

> ℹ️ You’ll see the estimator at `/estimator`. Upload 2–6 photos and pick a service.

---

## 2) Environment Variables

Create `.env.local` and set:
```
OPENAI_API_KEY=sk-...
```

> Get a key from https://platform.openai.com/. The estimator calls the **Chat Completions** API with `gpt-4o-mini` and **image inputs**.

---

## 3) Production Build & Deploy

```bash
npm run build
npm start
```

**Vercel (recommended):**
```bash
npm i -g vercel
vercel
```
Set `OPENAI_API_KEY` in your Vercel Project settings → Environment Variables.

---

## 4) Customize Pricing

Edit `lib/pricing.ts`:
```ts
export const SERVICE_RATES_PER_SQFT = {
  house: 0.15,
  windows: 0.20,
  roof: 0.35,
  driveway: 0.12,
  gutters: 0.18
};
export const MIN_JOB_FEE = 125;
export const COMPLEXITY_MULTIPLIER = (c:number) => 0.8 + (c-1)*0.15;
```

---

## 5) SEO

- Title/description/keywords: `app/layout.tsx`
- Add more content sections to `app/page.tsx` as needed.

---

## 6) Contact Info (Pre-filled)

- Phone: **870-520-0650**
- Email: **fosterdustin59022@gmail.com**
- Address: **4804 Antosh Cir, Jonesboro, AR 72404**

Edit `components/Footer.tsx` to change.

---

## Notes

- The estimator uses AI to infer **visible area and complexity** from images. It returns a **conservative** estimate and applies your configurable rates. This is *real inference*, not a mock. Always confirm on-site before finalizing price.
- Keep photo uploads under ~6 images per run for speed/cost.
