export default function Testimonials() {
  const reviews = [
    { name: "Sarah M.", location: "Paragould, AR", text: "Sparkling windows and spotless siding—my home looks brand new!" },
    { name: "James R.", location: "Blytheville, AR", text: "Showed up on time and over-delivered. Driveway is bright again." },
    { name: "Tina K.", location: "Jonesboro, AR", text: "Professional, friendly, and fair pricing. Roof wash was dramatic." },
    { name: "Marcus W.", location: "Trumann, AR", text: "They took our storefront to another level. Customers noticed!" },
    { name: "Alyssa P.", location: "Brookland, AR", text: "Fast quote, easy scheduling, and beautiful results." }
  ];
  return (
    <section id="testimonials" className="section">
      <div className="container">
        <h2 className="text-3xl md:text-4xl font-bold text-hackerBlue mb-8 text-center">★★★★★ What Your Neighbors Say</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {reviews.map((r, i) => (
            <div key={i} className="card">
              <p className="italic">"{r.text}"</p>
              <p className="mt-4 font-semibold text-hackerGreen">{r.name} • {r.location}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
